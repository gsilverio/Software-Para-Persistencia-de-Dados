package com.persist.data.interfaces;

public interface Identifiable<ID> {

    ID getId();
}
