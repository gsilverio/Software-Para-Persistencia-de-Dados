package com.persist.data;

import com.persist.data.view.AppView;
import javafx.application.Application;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Atividade3 {
	public static void main(String[] args) {
		Application.launch(AppView.class, args);
	}
}