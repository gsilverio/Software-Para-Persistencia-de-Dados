package com.persist.data.dto;

import java.util.Date;

public class ToDoDTO {

    private Long id;

    private String descricao;

    public Date dataCriacao;



}
